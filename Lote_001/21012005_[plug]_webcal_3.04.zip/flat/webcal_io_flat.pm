# WebCal - a web based calendar program.
# Released under the GNU GPL.  A text version of the GPL should have come
# with this program in the file "GPL.txt".
# Copyright 1999 Michael Arndt
#

#
# This file contains perl subroutines used for data input and output.
# These subroutine are for use with flat file databases.
#

package webcal_io;
require Exporter;
@ISA = qw(Exporter);
@EXPORT = qw(setup_items_hash del replace_record add_record del_calendar2 get_next_index set_all_unmodified input_check dbh_setup dbh_close);
use CGI;
use CGI::Carp qw(fatalsToBrowser);
use Time::Local;
use Fcntl ':flock';
use strict;

#
# Subroutine to set up the items hash
#
# Either we only get the items for a specific day, or we get the items for the entire
# month given, or we get the items for the current month plus the next month (for 
# reminder checking), or we get all the items.
#
sub setup_items_hash () {
	my ($type,$date) = (@_);
	my (%all_items,%sub_items,%pers_items,$index,$idate,$subindex,$modified,$user,$shour,$ehour,$string,$link,$rsec,$notes,@sub_cals,$misc_date,$y,$sub_cal,$date2,$misc_date2,@lines,%get_index_flags,%new_index);
	$type = "all" if (! $type);
	if ($type eq "today") {
		$date = &webcal_shared::get_current if (! $date);
		if ($date =~ /(\d{4})(\d{2})(\d{2})/) {
			my $year = $1;
			my $month = $2;
			my $day = $3;
			my $time = timelocal 1,1,1,$day,($month-1),($year-1900);
			my $dow = ("Sun","Mon","Tue","Wed","Thu","Fri","Sat")[(localtime($time))[6]];
			$misc_date = "$year,$month,$day,$dow";
		}
	} elsif ($type eq "month") {
		if ($date =~ /^(\d{4})(\d{2})/) {
			my $year = $1;
			my $month = $2;	
			$misc_date = "$year,$month";
		}
	} elsif ($type eq "rem") {
		$date = &webcal_shared::get_current;
		if ($date =~ /^(\d{4})(\d{2})/) {
			my $year = $1;
			my $month = $2;	
			$misc_date = "$year,$month";
			$date = $year.$month;
			$month++;
			if ($month == 13) {
				$year++;
				$month = "01";
			}
			$month = "0".$month if ($month !~ /\d{2}/);
			$misc_date2 = "$year,$month";
			$date2 = $year.$month;
		}
	} elsif ($type eq "week") {
		$date = &webcal_shared::get_current if (! $date);
		if ($date =~ /(\d{4})(\d{2})(\d{2})/) {
			my $year = $1;
			my $month = $2;
			my $day = $3;
			$misc_date = "$year,$month";
			$date = $year.$month;
			if ($day < 7) {
				$month = $month - 1;
				if ($month == 0) {
					$year = $year - 1;
					$month = "12";
				}		
				$month = "0".$month if ($month !~ /\d{2}/);
				$misc_date2 = "$year,$month";
				$date2 = $year.$month;
			} elsif ($day > 22) {
				$month++;	
				if ($month == 13) {
					$year++;
					$month = "01";
				}
				$month = "0".$month if ($month !~ /\d{2}/);
				$misc_date2 = "$year,$month";
				$date2 = $year.$month;
			} else {
				$misc_date2 = "99,99";
				$date2 = "9999";
			}
		}
	}
	open(DB, "<$::DATABASE");
	flock DB, LOCK_SH or die "$::webcal_conf::ERROR_STRING12 $::DATABASE: $!\n";
	while (<DB>) {
		next if /^#/;
		chomp;
		push(@lines,$_);
		($index, $subindex, $modified, $user, $idate, $shour, $ehour, $string, $link, $rsec, $notes) = split(/\|{3}/, $_);
		$get_index_flags{$index} = 1 if ($type eq "all");
		if ($type eq "month") {
			if ($idate =~ /^(.+),(.+),.+,.+$/) {
				my $iym = "$1,$2";
				$get_index_flags{$index}++ if ($misc_date =~ /$iym/)
			} else {
				my $iym = substr($idate,0,6);
				$get_index_flags{$index}++ if ($date eq $iym);
			}
		} elsif (($type eq "week") || ($type eq "rem")) {
			if ($idate =~ /^(.+),(.+),.+,.+$/) {
				my $iym = "$1,$2";
				$get_index_flags{$index}++ if (($misc_date =~ /$iym/) || ($misc_date2 =~ /$iym/));
			} else {
				my $iym = substr($idate,0,6);
				$get_index_flags{$index}++ if (($date eq $iym) || ($date2 eq $iym));
			}	
		} elsif ($type eq "today") {
			if (($misc_date =~ /$idate/) || ($date eq $idate)) {
				$get_index_flags{$index}++;	
			}
		}
	}
	flock DB, LOCK_UN or die "$::webcal_conf::ERROR_STRING13 $::DATABASE: $!\n";
	close(DB);
	for (@lines) {
		($index, $subindex, $modified, $user, $idate, $shour, $ehour, $string, $link, $rsec, $notes) = split(/\|{3}/, $_);
		if ($get_index_flags{$index}) {
			$all_items{$index}{$subindex}{'modified'} = $pers_items{$index}{$subindex}{'modified'} = $modified;
			$all_items{$index}{$subindex}{'user'} = $pers_items{$index}{$subindex}{'user'} = $user;
			$all_items{$index}{$subindex}{'idate'} = $pers_items{$index}{$subindex}{'idate'} = $idate;
			$all_items{$index}{$subindex}{'shour'} = $pers_items{$index}{$subindex}{'shour'} = $shour;
			$all_items{$index}{$subindex}{'ehour'} = $pers_items{$index}{$subindex}{'ehour'} = $ehour;
			$all_items{$index}{$subindex}{'string'} = $pers_items{$index}{$subindex}{'string'} = $string;
			$all_items{$index}{$subindex}{'link'} = $pers_items{$index}{$subindex}{'link'} = $link;
			$all_items{$index}{$subindex}{'rsec'} = $pers_items{$index}{$subindex}{'rsec'} = $rsec;
			$all_items{$index}{$subindex}{'notes'} = $pers_items{$index}{$subindex}{'notes'} = $notes;
		}
	}
	@sub_cals = split(/\s+/,$::webcal_conf::SUBSCRIBE) if ($::webcal_conf::SUBSCRIBE);
	$y = &get_next_index;
	for $sub_cal (@sub_cals) {
		next unless $sub_cal =~ /\w+/;
		undef %get_index_flags;
		undef %new_index;
		undef @lines;
		$sub_cal =~ s/\+/ /g;
		my $sub_db = "$::webcal_conf::DB_DIR/$sub_cal/cal.dat";
		next unless ( -f "$::webcal_conf::DB_DIR/$sub_cal/cal.dat" );
		open (DB, "<$sub_db") or die "$::webcal_conf::ERROR_STRING12 $sub_db: $!\n";
		flock DB, LOCK_SH or die "$::webcal_conf::ERROR_STRING12 $sub_db $!\n";
		while (<DB>) {
			next if /^#/;
			chomp;
			push(@lines,$_);
			($index, $subindex, $modified, $user, $idate, $shour, $ehour, $string, $link, $rsec, $notes) = split(/\|{3}/,$_);
			$get_index_flags{$index} = 1 if ($type eq "all");
			if ($type eq "month") {
				if ($idate =~ /^(.+),(.+),.+,.+$/) {
					my $iym = "$1,$2";
					$get_index_flags{$index}++ if ($misc_date =~ /$iym/)
				} else {
					my $iym = substr($idate,0,6);
					$get_index_flags{$index}++ if ($date eq $iym);
				}
			} elsif (($type eq "rem") || ($type eq "week")) {
				if ($idate =~ /^(.+),(.+),.+,.+$/) {
					my $iym = "$1,$2";
					$get_index_flags{$index}++ if (($misc_date =~ /$iym/) || ($misc_date2 =~ /$iym/));
				} else {
					my $iym = substr($idate,0,6);
					$get_index_flags{$index}++ if (($date eq $iym) || ($date2 eq $iym));
				}	
			} elsif ($type eq "today") {
				if (($misc_date =~ /$idate/) || ($date eq $idate)) {
					$get_index_flags{$index}++;	
				}
			}
		}
		flock DB, LOCK_UN or die "$::webcal_conf::ERROR_STRING13 $sub_db: $!\n";
		close(DB);
		for (@lines) {
			($index, $subindex, $modified, $user, $idate, $shour, $ehour, $string, $link, $rsec, $notes) = split(/\|{3}/,$_);
			$new_index{$index} = $y++ if (! $new_index{$index});
			if ($get_index_flags{$index}) {
				$all_items{$new_index{$index}}{$subindex}{'modified'} = $sub_items{$new_index{$index}}{$subindex}{'modified'} = $modified;
				$all_items{$new_index{$index}}{$subindex}{'user'} = $sub_items{$new_index{$index}}{$subindex}{'user'} = $user;
				$all_items{$new_index{$index}}{$subindex}{'idate'} = $sub_items{$new_index{$index}}{$subindex}{'idate'} = $idate;
				$all_items{$new_index{$index}}{$subindex}{'shour'} = $sub_items{$new_index{$index}}{$subindex}{'shour'} = $shour;
				$all_items{$new_index{$index}}{$subindex}{'ehour'} = $sub_items{$new_index{$index}}{$subindex}{'ehour'} = $ehour;
				if ($::webcal_conf::SHOW_SUB_CAL_NAME) {
					$all_items{$new_index{$index}}{$subindex}{'string'} = $sub_items{$new_index{$index}}{$subindex}{'string'} = "<span class=sub-cal>$sub_cal</span> $string";
				} else {
					$all_items{$new_index{$index}}{$subindex}{'string'} = $sub_items{$new_index{$index}}{$subindex}{'string'} = $string;
				}
				$all_items{$new_index{$index}}{$subindex}{'link'} = $sub_items{$new_index{$index}}{$subindex}{'link'} = $link;
				$all_items{$new_index{$index}}{$subindex}{'rsec'} = $sub_items{$new_index{$index}}{$subindex}{'rsec'} = $rsec;
				$all_items{$new_index{$index}}{$subindex}{'notes'} = $sub_items{$new_index{$index}}{$subindex}{'notes'} = $notes;
			}
		}
	}
	return (\%all_items,\%sub_items,\%pers_items);
}

#
# Subroutine to delete records from a database file.
#
sub del() {
	my ($index) = (@_);
	my ($line, $delete, $index2);
	open (DB, "<$::DATABASE") or die "$::webcal_conf::ERROR_STRING28: $!\n";
	open (TEMP, ">$::TEMPFILE") or die "$::webcal_conf::ERROR_STRING28: $!\n";
	flock DB, LOCK_SH or die "$::webcal_conf::ERROR_STRING12 $::DATABASE: $!\n";
	flock TEMP, LOCK_EX or die "$::webcal_conf::ERROR_STRING12 $::TEMPFILE: $!\n";
	while (<DB>) {
		chop;
		$line = $_;
		$delete = 0;
		$index2 = (split(/\|{3}/,$_))[0];
		if ($index2 == $index) {
        	$delete = 1;
		}
		print TEMP "$line\n" unless ($delete == 1);
    }
	unlink($::DATABASE);
	rename($::TEMPFILE,$::DATABASE);
	flock TEMP, LOCK_UN or die "$::webcal_conf::ERROR_STRING13 $::TEMPFILE: $!\n";
	flock DB, LOCK_UN or die "$::webcal_conf::ERROR_STRING13 $::DATABASE: $!\n";
	close(TEMP);
	close(DB);
	return 1;
}

#
# Subroutine to add records to a database file.
#
sub add_record() {
	my ($index,$subindex,$user,$date,$stime,$etime,$string,$link_string,$rsec,$notes) = (@_);
	my ($record);
	$record = join '|||', $index, $subindex, "1", $user, $date, $stime, $etime, $string, $link_string, $rsec, $notes;
	open (DB, ">>$::DATABASE") or die "$::webcal_conf::ERROR_STRING28: $!\n";
	flock DB, LOCK_EX or die "$::webcal_conf::ERROR_STRING12 $::DATABASE: $!\n";
	print DB "$record\n";
	flock DB, LOCK_UN or die "$::webcal_conf::ERROR_STRING13 $::DATABASE: $!\n";
	close(DB);
	return 1;
}

#
# subroutine to del all references to a calendar.
#
sub del_calendar2 () {
	my (@files,$dir);
	if (! $::calendar) {
		&webcal_shared::error_page("$webcal_conf::ERROR_STRING8");
	}
	$dir = "$webcal_conf::DB_DIR/$::calendar";
	opendir DIR, $dir or die "$webcal_conf::ERROR_STRING1 $dir: $!\n";
	@files = readdir DIR;
	closedir DIR;
	for (@files) {
		unlink("$dir/$_") if (-f "$dir/$_");
	}
	rmdir($dir) or die "$webcal_conf::ERROR_STRING28: $!\n";
	print "$webcal_conf::STRING110\n";
	&webcal_shared::print_footer("1");
	return 1;
}

#
# Subroutine to get next index to use.
#
sub get_next_index() {
	my ($next,$index,@indexes);
	open (DB, "<$::DATABASE") or die "$::webcal_conf::ERROR_STRING28: $!\n";
	flock DB, LOCK_SH or die "$::webcal_conf::ERROR_STRING12 $::DATABASE: $!\n";
	while (<DB>) {
		next if (/^#/);
		chomp;
		$index = (split(/\|{3}/, $_))[0];
		push(@indexes,$index);
	}
	flock DB, LOCK_UN or die "$::webcal_conf::ERROR_STRING13 $::DATABASE: $!\n";
	close(DB);
	@indexes = sort {$a <=> $b} @indexes;
	$next = pop(@indexes);
	$next++;
	return $next;
}

#
# subroutine to set all items as unmodified for calendar after a synch
#
sub set_all_unmodified {
	my ($line,$index,$subindex,$modified,$user,$idate,$shour,$ehour,$string,$link,$rsec,$notes);
	open (DB, "<$::DATABASE") or die "$::webcal_conf::ERROR_STRING28: $!\n";
	open (TEMP, ">$::TEMPFILE") or die "$::webcal_conf::ERROR_STRING28: $!\n";
	flock DB, LOCK_SH or die "$::webcal_conf::ERROR_STRING12 $::DATABASE: $!\n";
	flock TEMP, LOCK_EX or die "$::webcal_conf::ERROR_STRING12 $::TEMPFILE: $!\n";
	while (<DB>) {
		chop;
		($index, $subindex, $modified, $user, $idate, $shour, $ehour, $string, $link, $rsec, $notes) = split(/\|{3}/, $_);
		$line = join '|||', $index, $subindex, "0", $user, $idate, $shour, $ehour, $string, $link, $rsec, $notes; 
		print TEMP "$line\n";
    }
	unlink($::DATABASE);
	rename($::TEMPFILE,$::DATABASE);
	flock TEMP, LOCK_UN or die "$::webcal_conf::ERROR_STRING13 $::TEMPFILE: $!\n";
	flock DB, LOCK_UN or die "$::webcal_conf::ERROR_STRING13 $::DATABASE: $!\n";
	close(TEMP);
	close(DB);
	return 1;
}

#
# Subroutine to handle bad input for a flat file database.  If in a relational
# database module, just return the string.
#
sub input_check() {
	my ($string) = (@_);
	if ($string =~ /\|\|\|/) {
		return "-1";
	}
	if ($string =~ /\|$/) {
		$string=$string." ";
	} elsif ($string =~ /^\|/) {
		$string=" ".$string;
	}
	return $string;
}

#
# Subroutine to set up a database handle.  Just return for flat files.
#
sub dbh_setup() {
	return 1;
}	

#
# Subroutine to disconnect from database.  Just return for flat files.
#
sub dbh_close() {
	return 1;
}

# leave this 1 here for the require...
1;
