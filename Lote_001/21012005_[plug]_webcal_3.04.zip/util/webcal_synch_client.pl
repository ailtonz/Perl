#!/usr/bin/perl -w

use strict;
use Time::Local;
use LWP::UserAgent;
use HTTP::Request;
use URI::Escape;
use PDA::Pilot;
use Data::Dumper;
use Getopt::Std;

$| = 1;

#
# WebCal - a web based calendar program.
# Released under the GNU GPL.  A text version of the GPL should have come
# with this program in the file "GPL.txt".
# Copyright 2000 Michael Arndt
# Thanks to Sun Microsystems for funding development of the Palm Pilot synch code.
#

#
# This script, along with the webcal_synch_server.cgi script on the WebCal
# server, are used to synch the palm pilot with WebCal.  You must have the
# pilot-link program installed, along with the Perl5 module that comes with
# it, in addition to LWP and it's supporting modules.
#
# Known issues: 
#
#  1. This script is meant for putting items from WebCal onto your Pilot.
#     Because of this, and because WebCal does not support all the complex 
#     repeating events that the Pilot does, items which can not be translated
#     from the Pilot to WebCal are re-written as a simple item in WebCal,
#     kept unchanged in the Pilot, and a warning is printed.  Be aware that
#     if you then change that WebCal item and re-synch, that change will then
#     overwrite the original item in the Pilot.
#
#  2. The Pilot does not support events that start on one day and end on 
#     another.  These items are written to the Pilot as just a single item
#     that starts on the first day and ends at midnight that night.  The
#     next day part of the item is discarded on the Pilot.
#
#  3. Items from calendars which you subscribe to are just written to the pilot
#     on every synch when using the -a switch.  Changes made to these items on 
#     the Pilot will be lost when the next synch is done, and the latest WebCal
#     items for the subscribed-to calendars will be written in again.  The
#     'category' field, which is currently unused in the pilot, is used to keep
#     track of these items, so this is a bit of a kludge.
#

#
# global variables;
#
use vars qw($opt_u $opt_p $opt_c $opt_d $opt_s $opt_q $opt_t $opt_f $opt_a);
my ($uname,$pass,$cal,$wc_items_ref,$sub_items_ref,$new_wc_index,$num_orig_wc_items,$num_orig_db_items);
my ($DB,$device,$socket,$dlp,$db,$db_items_ref,$orig_db_ref,%old_db_index,%new_db_index,@warnings);
my ($new_wc_ref,$del_wc_ref,$new_db_ref,$del_db_ref,%old_db_items,$server,$Q,$T,$F,$A);
my $prog = $0;
$prog =~ s,.*/,,g;

#
# get user and calendar info
# command line overrides the .wccynchrc file
#
&help unless getopts("u:p:c:d:s:qtfa");
$uname = "";
$pass = "";
$cal = "";
$device = "/dev/ttyqe";
$server = "http://localhost/cgi-bin/webcal/protected/webcal_synch_server.cgi";
$Q = 0;
$T = 0;
$F = 0;
$A = 0;
if (-f "$ENV{'HOME'}/.wcsynchrc") {
	open (WCS, "<$ENV{'HOME'}/.wcsynchrc") or die "Error opening .wcsynchrc file!\n\n";
	while(<WCS>) {
		next if /^#/;
		$uname = $1  if /user\w*\s+(\S+)/;
		$pass = $1   if /pass\w*\s+(\S+)/;
		$cal = $1    if /cal\w*\s+(.*)/;
		$device = $1 if /device\s+(\S+)/;	
		$server = $1 if /server\s+(\S+)/;
		$Q = 1       if /quiet/;
	}
	close(WCS);
}
$uname = $opt_u if ($opt_u);
$pass = $opt_p if ($opt_p);
$cal = $opt_c if ($opt_c);
$device = $opt_d if ($opt_d);
$server = $opt_s if ($opt_s);
$Q++ if ($opt_q);
$T++ if ($opt_t);
$F++ if ($opt_f);
$A++ if ($opt_a);
die "no username given. aborting!\n\n" if (! $uname);
die "no calendar given. aborting!\n\n" if (! $cal);
if (! $pass) {
	print "\nWebCal password for $cal: ";
	system "stty -echo";
	chop($pass=<STDIN>);
	print "\n\n";
	system "stty echo";
}
die "no password given. aborting!\n\n" if (! $pass);

#
# get webcal data
#
($wc_items_ref,$sub_items_ref) = &setup_wc_data();
$num_orig_wc_items = keys %$wc_items_ref;

#
# get pilot data
#
print "\n>> Press synch now! <<\n\n";
$DB = "DatebookDB";
$socket = PDA::Pilot::openPort($device);
$dlp = PDA::Pilot::accept($socket);
$db = $dlp->open($DB);
if ($db) {
	($db_items_ref,$orig_db_ref) = &setup_db_data($db);
	$num_orig_db_items = keys %$orig_db_ref;
	$db->close();
} else {
	print "No entries in Pilot.\n\n";
	$num_orig_db_items = 0;
}	

#
# compare data
#
($new_wc_ref,$del_wc_ref,$new_db_ref,$del_db_ref) = &compare($wc_items_ref,$db_items_ref);

#
# update webcal data
#
&update_wc($new_wc_ref,$del_wc_ref);

#
# update palm pilot data, we are then done with the pilot.
#
&update_db($new_db_ref,$del_db_ref,$sub_items_ref);
undef $dlp;

#
# tell webcal server to mark all items for this calendar as unmodified.
#
if (! $T) {
	&lwp_fetch("cal=$cal&function=set_unmod");
}

#
# print out any warnings.
#
if (! $Q) {
	print "\n";
	for (@warnings) {
		print;
	}
}
print "Synch complete!\n\n";

#
# subroutine to setup hash of webcal items
#
sub setup_wc_data {
	my ($results,%items,%sub_items,$type,$indexes,$index,$subindex,$modified,$user,$date,$shour,$ehour,$string,$link,$rsec,$notes,$x,$c,@lines,$line,$last_index);
	$x = $c = $last_index = 0;
	print "Getting items from WebCal: [0]" if (! $T);
	print "Getting WebCal data\n" if ($T);
	$results = &lwp_fetch("cal=$cal&function=get");
	@lines = split(/\n/,$results);
	for $line (@lines) {
		chomp $line;
		$type     = $line if ($x == 0);
		$indexes  = $line if ($x == 1);
		$modified = $line if ($x == 2);
		$user     = $line if ($x == 3);
		$date     = $line if ($x == 4);
		$shour    = $line if ($x == 5);
		$ehour    = $line if ($x == 6);
		$string   = $line if ($x == 7);
		$link     = $line if ($x == 8);
		$rsec     = $line if ($x == 9);
		$notes    = $line if ($x == 10);
		if ($x == 10) {
			if ($type eq "pers") {
				($index,$subindex) = split(/:/,$indexes);
				$items{$index}{$subindex}{'modified'} = $modified;
				$items{$index}{$subindex}{'user'}     = $user;
				$items{$index}{$subindex}{'date'}     = $date;
				$items{$index}{$subindex}{'shour'}    = $shour;
				$items{$index}{$subindex}{'ehour'}    = $ehour;
				$items{$index}{$subindex}{'string'}   = $string;
				$items{$index}{$subindex}{'link'}     = $link;
				$items{$index}{$subindex}{'rsec'}     = $rsec;
				$notes =~ s/<BR>/\n/g if ($notes);
				$items{$index}{$subindex}{'notes'}    = $notes;
				if ($index != $last_index) {
					$c++;
					&display_counter($c) if (! $T);
				}
				$last_index = $index;
			} elsif ($type eq "sub") {
				$x = 0, next unless ($A);
				($index,$subindex) = split(/:/,$indexes);
				$sub_items{$index}{$subindex}{'modified'} = $modified;
				$sub_items{$index}{$subindex}{'user'}     = $user;
				$sub_items{$index}{$subindex}{'date'}     = $date;
				$sub_items{$index}{$subindex}{'shour'}    = $shour;
				$sub_items{$index}{$subindex}{'ehour'}    = $ehour;
				$string =~ s/<span\sclass=sub-cal>(.*?)<\/span>/($1)/;
				$sub_items{$index}{$subindex}{'string'}   = $string;
				$sub_items{$index}{$subindex}{'link'}     = $link;
				$sub_items{$index}{$subindex}{'rsec'}     = $rsec;
				$notes =~ s/<BR>/\n/g if ($notes);
				$sub_items{$index}{$subindex}{'notes'}    = $notes;
				if ($index != $last_index) {
					$c++;
					&display_counter($c) if (! $T);
				}
				$last_index = $index;
			} else {
				die "Bad type while getting WebCal data: $type\n";
			}
			$x = 0;
			next;
		}
		$x++;
	}
	print "\n" if (! $T);
	return (\%items, \%sub_items);
}

#
# subroutine to setup hash of datebook items
#
sub setup_db_data{
	my ($db) = (@_);
	my ($r,$x,$c,$date,$sh,$sm,$eh,$em,$id,$rsec,%items,%orig_db);
	my ($year,$month,$day,$misc_year,$misc_month,$misc_day,$misc_dow,$begin,$consecutive_days);
	$x = $c = 0;
	print "Getting items from Pilot:  [0]" if (! $T);
	print "Getting Pilot data\n" if ($T);
	while ($r = $db->getRecord($x++)) {
		next if (! $r->{'description'});
		#
		# Skip items that have their category set to 1, which indicates it is an item from
        # a subscribed-to calendar that will be re-synched.
		#	
		if (($A) && ($r->{'category'} == 1)) {
			next;
		} 
		$c++;
		&display_counter($c) if (! $T);
		$consecutive_days = 0;
		$id = $r->{'id'};
		$year = $r->{'begin'}[5] + 1900;
		$month = $r->{'begin'}[4] + 1;
		$day = $r->{'begin'}[3];
		($year,$month,$day) = &two_digit($year,$month,$day);
		$begin = $year . $month . $day;
		if (! $r->{'repeat'}) {
			$items{$id}{'1'}{'date'} = $begin;
		} else {
			if ($r->{'repeat'}{'type'} eq "Daily") {
				if ($r->{'repeat'}{'frequency'} != 1) {
					push(@warnings, "WARNING: Events repeating every $r->{'repeat'}{'frequency'} days not supported by WebCal:\n");
					push(@warnings, "  \"$r->{'description'}\" will be written as single day in WebCal.\n\n");
					$items{$id}{'1'}{'date'} = $begin;
				} else {
					if ($r->{'repeat'}{'end'}) {
						my $eyear = $r->{'repeat'}{'end'}[5] + 1900;
						my $emonth = $r->{'repeat'}{'end'}[4] + 1;
						my $eday = $r->{'repeat'}{'end'}[3];
						($eyear,$emonth,$eday) = &two_digit($eyear,$emonth,$eday);
						my $end = $eyear . $emonth . $eday;
						$consecutive_days = &days_length($begin,$end);	
						$consecutive_days++;
						$items{$id}{'1'}{'date'} = $begin;
					} else {
						push(@warnings, "WARNING: Events repeating every day until the end of time are not supported by WebCal:\n");
						push(@warnings, "  \"$r->{'description'}\" will be written as single day in WebCal.\n\n");
						$items{$id}{'1'}{'date'} = $begin;
					}
				}
			} elsif ($r->{'repeat'}{'type'} eq "Weekly") {
				if ($r->{'repeat'}{'frequency'} != 1) {
					push(@warnings, "WARNING: Events repeating every $r->{'repeat'}{'frequency'} weeks not supported by WebCal:\n");
					push(@warnings, "  \"$r->{'description'}\" will be written as single day in WebCal.\n\n");
					$items{$id}{'1'}{'date'} = $begin;
				} else {
					$misc_day = ".*";
					$misc_dow = "";
					my $x = 0;
					my $flag = 0;
					my @days = qw(Sun Mon Tue Wed Thu Fri Sat);
					for (@{ $r->{'repeat'}{'days'} }) {
						if ($r->{'repeat'}{'days'}[$x] == 1) {
							if (! $misc_dow) {
								$misc_dow = $days[$x];
							} else {
								if (! $flag) {
									push(@warnings, "WARNING: Events repeating weekly on multiple days not supported by WebCal:\n");
									push(@warnings, "  \"$r->{'description'}\" will be written as repeating only on $misc_dow in WebCal.\n\n");
									$flag++
								}
							}
						} 
						$x++;
					}
					if ($r->{'repeat'}{'end'}) {
						my $eyear = $r->{'repeat'}{'end'}[5] + 1900;
						my $emonth = $r->{'repeat'}{'end'}[4] + 1;
						if ($eyear != $year) {
							$misc_year = ".*";
						} else {
							$misc_year = $year;
						}
						if ($emonth != $month) {
							$misc_month = ".*";
						} else {
							$misc_month = $month;
						}
					} else {
						$misc_year = $misc_month = ".*";
					}
					$items{$id}{'1'}{'date'} = "${misc_year},${misc_month},${misc_day},${misc_dow}";
				}
			} elsif ($r->{'repeat'}{'type'} eq "MonthlyByDate") {
				if ($r->{'repeat'}{'frequency'} != 1) {
					push(@warnings, "WARNING: Events repeating every $r->{'repeat'}{'frequency'} months not supported by WebCal:\n");
					push(@warnings, "  \"$r->{'description'}\" will be written as single day in WebCal.\n\n");
					$items{$id}{'1'}{'date'} = $begin;
				} else {
					$misc_dow = ".*";
					$misc_month = ".*";
					$misc_day = $day;
					if ($r->{'repeat'}{'end'}) {
						my $end_year = $r->{'repeat'}{'end'}[5] + 1900;
						if ($end_year == $year) {
							$misc_year = $year;
						} else {
							$misc_year = ".*";
						}
					} else {
						$misc_year = ".*";
					}
					$items{$id}{'1'}{'date'} = "${misc_year},${misc_month},${misc_day},${misc_dow}";
				}
			} elsif ($r->{'repeat'}{'type'} eq "MonthlyByDay") {
				if ($r->{'repeat'}{'frequency'} != 1) {
					push(@warnings, "WARNING: Events repeating every $r->{'repeat'}{'frequency'} months not supported by WebCal:\n");
					push(@warnings, "  \"$r->{'description'}\" will be written as single day in WebCal.\n\n");
					$items{$id}{'1'}{'date'} = $begin;
				} else {
					$misc_month = ".*";
					my @days = qw(Sun Mon Tue Wed Thu Fri Sat);
					$misc_dow = $days[$r->{'begin'}[6]];
					if ($r->{'repeat'}{'day'} <= 7) {
						$misc_day = "0[1-7]";
					} elsif ($r->{'repeat'}{'day'} <= 14) {
						$misc_day = "((0[8-9])|(1[0-4]))";
					} elsif ($r->{'repeat'}{'day'} <= 21) {
						$misc_day = "((1[5-9])|(2[0-1]))";
					} else {
						push(@warnings, "Warning: item \"$r->{'description'}\" being written as 4th $misc_dow of month.\n\n");
						$misc_day = "2[2-8]";
					}
					if ($r->{'repeat'}{'end'}) {
						my $end_year = $r->{'repeat'}{'end'}[5] + 1900;
						if ($end_year == $year) {
							$misc_year = $year;
						} else {
							$misc_year = ".*";
						}
					} else {
						$misc_year = ".*";
					}
					$items{$id}{'1'}{'date'} = "${misc_year},${misc_month},${misc_day},${misc_dow}";
				}	
			} elsif ($r->{'repeat'}{'type'} eq "Yearly") {
				if ($r->{'repeat'}{'frequency'} != 1) {
					push(@warnings, "WARNING: Events repeating every $r->{'repeat'}{'frequency'} months not supported by WebCal:\n");
					push(@warnings, "  \"$r->{'description'}\" will be written as single day in WebCal.\n\n");
					$items{$id}{'1'}{'date'} = $begin;
				} else {
					$misc_dow = ".*";
					$misc_day = $day;
					$misc_month = $month;
					$misc_year = ".*";
					$items{$id}{'1'}{'date'} = "${misc_year},${misc_month},${misc_day},${misc_dow}";
				}
			} else {
				push(@warnings, "bad repeat type: $r->{'repeat'} on item $r->{'description'}.\n\n");
			}
		}
		$sh = $r->{'begin'}[2];	
		$sm = $r->{'begin'}[1];	
		if ($r->{'end'}) {
			$eh = $r->{'end'}[2];	
			$em = $r->{'end'}[1];	
			($sh,$sm,$eh,$em) = &two_digit($sh,$sm,$eh,$em);
			$items{$id}{'1'}{'shour'} = $sh . $sm;
			$items{$id}{'1'}{'ehour'} = $eh . $em;	
		} else {
			$items{$id}{'1'}{'shour'} = 0;
			$items{$id}{'1'}{'ehour'} = 0;	
		}
		if ($r->{'alarm'}) {
			my $ad = $r->{'alarm'}{'advance'};
			my $un = $r->{'alarm'}{'units'};
			if ($un eq "minutes") {
				$rsec = $ad * 60;	
			} elsif ($un eq "hours") {
				$rsec = $ad * 3600;	
			} elsif ($un eq "days") {
				$rsec = $ad * 86400;	
			} else {
				push(@warnings, "bad reminder units: $un on item $r->{'description'}.\n\n");
			}
			if ($rsec) {
				$items{$id}{'1'}{'rsec'} = $rsec;
			} else {
				$items{$id}{'1'}{'rsec'} = 0;
			}
		} else {
			$items{$id}{'1'}{'rsec'} = 0;
		}
		$items{$id}{'1'}{'string'} = $r->{'description'};
		$items{$id}{'1'}{'string'} =~ s/\n/<BR>/g;
		if (defined $r->{'note'}) {
			$items{$id}{'1'}{'notes'} = $r->{'note'};
			$items{$id}{'1'}{'notes'} =~ s/\n/<BR>/g;
		} else {
			$items{$id}{'1'}{'notes'} = 0;
		}
		$items{$id}{'1'}{'modified'} = $r->{'modified'};
		$items{$id}{'1'}{'link'} = 0;
		if ($consecutive_days > 0) {
			my $x;
			for ($x=2;$x<=$consecutive_days;$x++) {
				my $y = $x - 1;
				my $date = &future_date($begin,$y);
				$items{$id}{$x}{'date'} = $date;
				$items{$id}{$x}{'shour'} = $items{$id}{'1'}{'shour'};
				$items{$id}{$x}{'ehour'} = $items{$id}{'1'}{'ehour'};
				$items{$id}{$x}{'rsec'} = $items{$id}{'1'}{'rsec'};
				$items{$id}{$x}{'string'} = $items{$id}{'1'}{'string'};
				$items{$id}{$x}{'modified'} = $items{$id}{'1'}{'modified'};
				$items{$id}{$x}{'link'} = $items{$id}{'1'}{'link'};
				$items{$id}{$x}{'notes'} = $items{$id}{'1'}{'notes'};
			}
		}
		%{ $orig_db{$id} } = %$r;
	}
	print "\n\n" if (! $T);
	return (\%items,\%orig_db);
}

#
# subroutine to update webcal data
#
sub update_wc {
	my ($add_ref,$del_ref) = (@_);
	my ($index,$subindex,$content,$add_count,$del_count,$c,$index_counter,$results);
	my (@lines,$line);
	$c = 0;
	$add_count = $del_count = $index_counter = 0;
	$del_count = keys %$del_ref;
	$add_count = keys %$add_ref;
	if (($del_count >= $num_orig_wc_items) && ($del_count > 0)) {
		print "\n\nCowardly refusing to delete all items in WebCal.\n\n";
		print "If you want to populate your Pilot with old WebCal items,\n";
		print "use the -f option to force all WebCal items to be written\n";
		print "to your Pilot, and vice-versa.\n\n";
	} else {
		print "Updating WebCal\n";
		print "    Deleting:           [0]" if (! $T);
		$content = "cal=$cal&function=del";
		$index_counter = 0;
		for $index (sort keys %$del_ref) {
			if ($T) {
				print "Would be deleting index $index from webcal.\n";
			} else {
				$content .= "&index${index_counter}=$index";
				if (! $add_ref->{$index}) {
					$c++;
					&display_counter($c);
				}
				$index_counter++;
			}
		}
		if ($index_counter) {
			&lwp_fetch($content);
		}
		print "\n" if (! $T);
		print "    Adding or Updating: [0]" if (! $T);
		$c = 0;
		$content = "cal=$cal&function=add";
		$index_counter = 0;
		for $index (sort keys %$add_ref) {
			if (! $T) {
				$c++;	
				&display_counter($c);
			}
			for $subindex (sort {$a <=> $b} keys %{ $add_ref->{$index} }) {
				if ($T) {
					print "Would be adding or updating item $add_ref->{$index}{$subindex}{'string'} (index $index:$subindex) to webcal.\n";
				} else {
					$content .= "&index${index_counter}=$index&subindex${index_counter}=$subindex&user${index_counter}=$add_ref->{$index}{$subindex}{'user'}&date${index_counter}=$add_ref->{$index}{$subindex}{'date'}&shour${index_counter}=$add_ref->{$index}{$subindex}{'shour'}&ehour${index_counter}=$add_ref->{$index}{$subindex}{'ehour'}&string${index_counter}=$add_ref->{$index}{$subindex}{'string'}&link${index_counter}=$add_ref->{$index}{$subindex}{'link'}&rsec${index_counter}=$add_ref->{$index}{$subindex}{'rsec'}&notes${index_counter}=$add_ref->{$index}{$subindex}{'notes'}";
					$index_counter++;
				}
			}
		}
		if (! $T) {
			if ($index_counter) {
				$results = &lwp_fetch($content);
				@lines = split(/\n/, $results);
				for $line (@lines) {
					if ($line =~ /index\s+(\w+)=(\d+)/) {
						$new_db_index{$1} = $2;
					}
				}
			}
			print "\n";
		}
	}
	return 1;
}

#
# subroutine to re-write the pilot datebook
#
sub update_db {
	my ($add_ref,$del_ref,$sub_ref) = (@_);
	my ($new,$index,$db,$x,$add_count,$del_count,$c,$r,$key);
	$c = 0;
	$add_count = $del_count = 0;
	$del_count = keys %$del_ref;
	#
	# first check to make sure we are not deleting everything.
	#
	if (($del_count >= $num_orig_db_items) && ($del_count > 0)) {
		print "\n\nCowardly refusing to delete all items in your Pilot.\n\n";
		print "If you want to populate WebCal with old Pilot items,\n";
		print "use the -f option, to force all Pilot items to be\n";
		print "written to WebCal, and vice-versa.\n\n";
	} else {
		#
		# OK, we are going to re-write the pilot datebook DB completely, so delete it first.
		#	
		print "Updating Pilot\n";
		print "    Deleting:           [$del_count]" if (! $T);
		if (! $T) {
			$dlp->delete($DB);
			$db = $dlp->create($DB, 'date', 'DATA', 0, 0);
		}
		if ($T) {
			for $index (sort keys %$del_ref) {
				print "Would be deleting index $index from pilot.\n";
			}
		}
		$x = 0;
		print "\n" if (! $T);
		print "    Adding or Updating: [0]" if (! $T);
		for $index (sort keys %$add_ref) {
			undef $new;
			if (! $T) {
				$new = $db->newRecord();
				#
				# So we are going to create a new item.  First check to see if it is really an old
				# item that has not changed, or if only the webcal index (pilot id) is new for the 
				# item.  If we can just use the old pilot record for the item, do that, otherwise
				# continue and convert the webcal data to a pilot entry.
				#
				if ($old_db_items{$index}) {
					if ($old_db_index{$index}) {
						$r = $orig_db_ref->{ $old_db_index{$index} };
						for $key (keys %$r) {
							$new->{$key} = $r->{$key};
						}
						if ($new_db_index{$index}) {
							$new->{'id'} = $new_db_index{$index};
						} else {
							$new->{'id'} = $index;
						}
					} else {
						$r = $orig_db_ref->{$index};
						for $key (keys %$r) {
							$new->{$key} = $r->{$key};
						}
					}
					$new->{'index'} = $x;
					$new->{'modified'} = 0;
					local $^W = 0;
					$db->setRecord($new);
					$^W = 1;
					$x++;
					next;
				}
			}
			#
			# Ok, this was not an old pilot item, we'll have to convert it from WebCal format to 
			# Pilot format.
			#	
			# if this item has *no* time associated with it, set the event=1, 
			# otherwise event=0. Not sure if this really has anything to do with
            # the time of items, but it seems to work this way. 
			#
		 	$r = &wc2db($add_ref,$index,"pers");
			for $key (keys %$r) {
				$new->{$key} = $r->{$key};
			}
			if ($T) {
				print "Would be adding or updating item $new->{'description'}(id:$index) to pilot.\n" unless ($old_db_items{$index});
			} else {
				# turn off warnings when setting record.  It complains about reminder time units for some reason.
				$new->{'index'} = $x;
				local $^W = 0;
				$db->setRecord($new);
				$^W = 1;
				$c++;
				&display_counter($c);
				$x++;
			}
		}
		#
		# now add the subscribed-to items if need be.
		#
		if ($A) {
			for $index (sort keys %$sub_ref) {
				if (! $T) {
					$new = $db->newRecord();
				}
				$r = &wc2db($sub_ref,$index,"sub");
				for $key (keys %$r) {
					$new->{$key} = $r->{$key};
				}
				#
				# Add in a category of 1, which denotes that it is an item from a subscribed-to calendar.
				#		
				$new->{'category'} = "1";
				$new->{'index'} = $x;
				$new->{'id'} = $x + 3000000;
				$x++;
				if ($T) {
					print "Would be adding or updating item $new->{'description'}(id:$index) to pilot.\n";
				} else {
					# turn off warnings when setting record.  It complains about reminder time units for some reason.
					local $^W = 0;
					$db->setRecord($new);
					$^W = 1;
					$c++;
					&display_counter($c);
				}
			}
		}
		print "\n" if (! $T);
	}
	return 1;
}

#
# subroutine to convert a WebCal item to a Pilot entry
#
sub wc2db {
	my ($ref,$index,$type) = (@_);
	my ($new,$sh,$sm,$eh,$em);
	if ($ref->{$index}{'1'}{'shour'} =~ /^(\d+)(\d{2})$/) {
		($sh,$sm) = ($1,$2);
		$new->{'event'} = 0;
	} else {
		($sh,$sm) = ("0","0");
		$new->{'event'} = 1;
	}
	$new->{'begin'}[0] = 0;
	$new->{'begin'}[1] = $sm;
	$new->{'begin'}[2] = $sh;
	if ($ref->{$index}{'1'}{'ehour'} =~ /^(\d+)(\d{2})$/) {
		($eh,$em) = ($1,$2);
	} else {
		($eh,$em) = ($sh,$sm);
	}
	$new->{'end'}[0] = 0;
	$new->{'end'}[1] = $em;
	$new->{'end'}[2] = $eh;
	if ($ref->{$index}{'1'}{'date'} =~ /(\d{4})(\d{2})(\d{2})/) {
		my $date = $1 . $2 . $3;
		my ($year, $month, $day) = ($1, $2, $3);
		my ($end_date,$eday,$emonth,$eyear);
		if (defined $ref->{$index}{'2'}) {
			if (($ref->{$index}{'2'}{'ehour'} ne "0") && ($ref->{$index}{'1'}{'shour'} ne "0") && ($ref->{$index}{'2'}{'ehour'} < $ref->{$index}{'1'}{'shour'})) {
				push(@warnings, "WARNING: Items that overlap days not supported by Pilot:\n");
				push(@warnings, "  Only day 1 of \"$ref->{$index}{'1'}{'string'}\" will be added.\n\n");
			} else {
				my $days = keys %{ $ref->{$index} };
				$days = $days - 1;
				my $end_date = &future_date($date,$days);
				($eyear,$emonth,$eday) = $end_date =~ (/(\d{4})(\d{2})(\d{2})/);	
				$emonth = $emonth - 1;
				$eyear = $eyear - 1900;
				$new->{'repeat'}{'end'}[3] = $eday;
				$new->{'repeat'}{'end'}[4] = $emonth;
				$new->{'repeat'}{'end'}[5] = $eyear;
				$new->{'repeat'}{'end'}[6] = 0;
				$new->{'repeat'}{'end'}[7] = 0;
				$new->{'repeat'}{'end'}[8] = 0;
				$new->{'repeat'}{'frequency'} = 1;
				$new->{'repeat'}{'type'} = "Daily";
				$new->{'repeat'}{'weekstart'} = 0;
			}
		}
		($eyear,$emonth,$eday) = ($year,$month,$day);	
		$month = $month - 1;
		$year = $year - 1900;
		$emonth = $emonth - 1;
		$eyear = $eyear - 1900;
		$new->{'begin'}[3] = $day;
		$new->{'begin'}[4] = $month;
		$new->{'begin'}[5] = $year;
		$new->{'end'}[3] = $eday;
		$new->{'end'}[4] = $emonth;
		$new->{'end'}[5] = $eyear;
		my $time = timelocal("0","0","12",$day,$month,$year);
		my $dow = localtime($time);
		$dow =~ s/^(\w{3}).*/$1/;
		my %days = qw(Sun 0 Mon 1 Tue 2 Wed 3 Thu 4 Fri 5 Sat 6);
		$new->{'begin'}[6] = $new->{'end'}[6] = $days{$dow};
		$new->{'begin'}[7] = $new->{'end'}[7] = 0;
		$new->{'begin'}[8] = $new->{'end'}[8] = 0;
	} else {
		if ((defined $ref->{$index}{'2'}) && ($ref->{$index}{'2'}{'ehour'} ne "0") && ($ref->{$index}{'1'}{'shour'} ne "0") && ($ref->{$index}{'2'}{'ehour'} < $ref->{$index}{'1'}{'shour'})) {
				push(@warnings, "WARNING: Items that overlap days not supported by Pilot:\n");
				push(@warnings, "  Only day 1 of \"$ref->{$index}{'1'}{'string'}\" will be added.\n\n");
		}
		my ($year, $month, $day, $dow) = $ref->{$index}{'1'}{'date'} =~ /(.*?),(.*?),(.*?),(.*)/;
		if ($dow eq ".*") {
			if ($month eq ".*") {
				$new->{'repeat'}{'frequency'} = 1;
				$new->{'repeat'}{'type'} = "MonthlyByDate";
				$new->{'repeat'}{'weekstart'} = 0;
				if ($year ne ".*") {
					$new->{'repeat'}{'end'}[3] = $day;
					$new->{'repeat'}{'end'}[4] = 0;
					$new->{'repeat'}{'end'}[5] = $year - 1900;
					$new->{'repeat'}{'end'}[7] = 0;
					$new->{'repeat'}{'end'}[8] = 0;
					$new->{'repeat'}{'end'}[9] = 0;
					$new->{'begin'}[5] = $new->{'end'}[5] = $year - 1900;
				}
				$new->{'begin'}[3] = $new->{'end'}[3] = $day;
				$new->{'begin'}[4] = $new->{'end'}[4] = 0;
				$new->{'begin'}[5] = $new->{'end'}[5] = 100;
			} else {
				$new->{'repeat'}{'frequency'} = 1;
				$new->{'repeat'}{'type'} = "Yearly";
				$new->{'repeat'}{'weekstart'} = 0;
				$new->{'begin'}[3] = $new->{'end'}[3] = $day;
				$new->{'begin'}[4] = $new->{'end'}[4] = $month - 1;
				$new->{'begin'}[5] = $new->{'end'}[5] = 100;
			}
			$new->{'begin'}[6] = $new->{'end'}[6] = 0;
			$new->{'begin'}[7] = $new->{'end'}[7] = 0;
			$new->{'begin'}[8] = $new->{'end'}[8] = 0;
		} else {
			my %days = qw(Sun 0 Mon 1 Tue 2 Wed 3 Thu 4 Fri 5 Sat 6);
			$new->{'begin'}[3] = $new->{'end'}[3] = 1;
			$new->{'begin'}[4] = $new->{'end'}[4] = 0;
			$new->{'begin'}[5] = $new->{'end'}[5] = 100;
			$new->{'begin'}[6] = $new->{'end'}[6] = $days{$dow};
			$new->{'begin'}[7] = $new->{'end'}[7] = 0;
			$new->{'begin'}[8] = $new->{'end'}[8] = 0;
			if ($day eq ".*") {
				my %days = qw(0 Sun 1 Mon 2 Tue 3 Wed 4 Thu 5 Fri 6 Sat);
				my $z;
				for $z ( 0..6 ) {
					if ($dow eq $days{$z}) {
						$new->{'repeat'}{'days'}[$z] = 1;
					} else {
						$new->{'repeat'}{'days'}[$z] = 0;
					}
				}
				$new->{'repeat'}{'frequency'} = 1;
				$new->{'repeat'}{'type'} = "Weekly";
				$new->{'repeat'}{'weekstart'} = 0;
			} else {
				my %days = qw(Sun 0 Mon 1 Tue 2 Wed 3 Thu 4 Fri 5 Sat 6);
				if ($day eq "0[1-7]") {
					$new->{'repeat'}{'day'} = $days{$dow};
				} elsif ($day eq "((0[8-9])|(1[0-4]))") {
					$new->{'repeat'}{'day'} = $days{$dow} + 7;
				} elsif ($day eq "((1[5-9])|(2[0-1]))") {
					$new->{'repeat'}{'day'} = $days{$dow} + 14;
				} elsif ($day eq "2[2-8]") {
					$new->{'repeat'}{'day'} = $days{$dow} + 21;
				}
				$new->{'repeat'}{'frequency'} = 1;
				$new->{'repeat'}{'type'} = "MonthlyByDay";
				$new->{'repeat'}{'weekstart'} = 0;
			}
		}			
	}
	if ($ref->{$index}{'1'}{'rsec'}) {
		my ($ad,$un);
		if ($ref->{$index}{'1'}{'rsec'} < 3600) {
			$un = "minutes";
			$ad = ($ref->{$index}{'1'}{'rsec'} / 60);
		} elsif ($ref->{$index}{'1'}{'rsec'} < 86400 ) {
			$un = "hours";
			$ad = ($ref->{$index}{'1'}{'rsec'} / 3600);
		} else {
			$un = "days";
			$ad = ($ref->{$index}{'1'}{'rsec'} / 86400);
		}
		$new->{'alarm'}{'advance'} = $ad;
		$new->{'alarm'}{'units'} = "$un";
	}
	$new->{'description'} = $ref->{$index}{'1'}{'string'};
	if ($ref->{$index}{'1'}{'notes'}) {
		$new->{'note'} = $ref->{$index}{'1'}{'notes'};
	} 
	$new->{'secret'} = 0;
	$new->{'modified'} = 0;
	$new->{'archived'} = 0;
	$new->{'category'} = 0;
	$new->{'id'} = $index;
	return $new;
}

#
# subroutine to compare webcal data and pilot data.  
# return hash refs for new and deleted webcal and pilot entries.
#
sub compare {
	my ($wc_ref,$db_ref) = (@_);
	my ($index,%new_wc,%del_wc,%new_db,%del_db,$c);
	my %counter = qw(1 | 2 / 3 - 4 \\ 5 | 6 / 7 - 8 \\); 
	$c = 1;
	$new_wc_index = "a";
	#
	# first look at all webcal entries, and see if they exist in the pilot.
	print "Comparing entries [|]" if (! $T);
	print "Comparing entries\n" if ($T);
	for $index (sort keys %$wc_ref) {
		if (! $T) {
			$c++;
			&display_counter($counter{$c});
			$c = 1 if ($c == 8);
		}
		if (defined $db_ref->{$index}) {
			#
			# pilot record exists for this item.
			#
			if ($db_ref->{$index}{'1'}{'modified'} == 1) {
				#
				# pilot record was modified since last synch.
				#
				if ($wc_ref->{$index}{'1'}{'modified'} == 1) {
					#
					# wc record was modified too, what to do!!!
					#
					push(@warnings, "Both records with index $index were modified, using webcal record.\n\n");
					&add_record(\%new_db,$wc_ref,$index,$index);
				} else {
					#
					# wc record not modified, keep the pilot record, and update wc.
					#
					$del_wc{$index}++;
					&add_record(\%new_db,$db_ref,$index,$index);
					&add_record(\%new_wc,$db_ref,$index,$index);
					$old_db_items{$index}++;
				}
			} else {
				#
				# pilot record not modified since last synch. 
				#
				if ($wc_ref->{$index}{'1'}{'modified'} == 1) {
					#
					# wc record was modified, use it for pilot
					#
					&add_record(\%new_db,$wc_ref,$index,$index);
				} else {
					#
					# neither record modified, keep old pilot record
					#
					&add_record(\%new_db,$db_ref,$index,$index);
					$old_db_items{$index}++;
				}
			}
		} else {
			#
			# no pilot record matches wc record.
			#
			if (($wc_ref->{$index}{'1'}{'modified'} == 1) || ($F)) {
				#
				# pilot record did not exist, and this is a new wc record, or we are in force mode.  Add to pilot.
				#
				&add_record(\%new_db,$wc_ref,$index,$index);
			} else {
				#
				# pilot record did not exist, and this is an old wc record. Must have been deleted from pilot, let's delete it from wc too.
				#
				$del_wc{$index}++;
			}
		}
	}
	#
	# now look at any pilot entries that did not exist in webcal.
	#
	for $index (sort keys %$db_ref) {
		if (! $T) {
			$c++;
			&display_counter($counter{$c});
			$c = 1 if ($c == 8);
		}
		if (defined $wc_ref->{$index}{'1'}) {
			#
			# this record was in both pilot and wc, already taken care of above
			#
			next;
		} else {
			#
			# no wc record matches pilot record
			#
			if (($db_ref->{$index}{'1'}{'modified'} == 1) || ($F)) {
				#
				# wc record did not exist, and this is a new pilot record, or we are in force mode.  Add to wc, and keep in pilot.
				#
				&add_record(\%new_wc,$db_ref,$new_wc_index,$index);
				&add_record(\%new_db,$db_ref,$new_wc_index,$index);
				$old_db_items{$new_wc_index}++;
				$old_db_index{$new_wc_index} = $index;
				$new_wc_index++;
			} else {
				#
				# wc record did not exist, and this is an old pilot record.  Must have been deleted from wc, delete it in pilot too.
				#
				$del_db{$index}++;
			}
		}
	}
	print "\n" if (! $T);
	return (\%new_wc, \%del_wc, \%new_db, \%del_db);
}

#
# subroutine to copy data from one hash to another
#
sub add_record {
	my($dest_ref,$source_ref,$dest_index,$source_index) = (@_);
	my ($subindex);
	for $subindex (sort keys %{ $source_ref->{$source_index} }) {
		$dest_ref->{$dest_index}{$subindex}{'modified'} = 0;
		$dest_ref->{$dest_index}{$subindex}{'date'}     = $source_ref->{$source_index}{$subindex}{'date'};
		$dest_ref->{$dest_index}{$subindex}{'shour'}    = $source_ref->{$source_index}{$subindex}{'shour'};
		$dest_ref->{$dest_index}{$subindex}{'ehour'}    = $source_ref->{$source_index}{$subindex}{'ehour'};
		$dest_ref->{$dest_index}{$subindex}{'string'}   = $source_ref->{$source_index}{$subindex}{'string'};
		$dest_ref->{$dest_index}{$subindex}{'link'}     = $source_ref->{$source_index}{$subindex}{'link'};
		$dest_ref->{$dest_index}{$subindex}{'rsec'}     = $source_ref->{$source_index}{$subindex}{'rsec'};
		$dest_ref->{$dest_index}{$subindex}{'notes'}    = $source_ref->{$source_index}{$subindex}{'notes'};
		if ($source_ref->{$source_index}{$subindex}{'user'}) {
			$dest_ref->{$dest_index}{$subindex}{'user'} = $source_ref->{$source_index}{$subindex}{'user'};
		} else {
			$dest_ref->{$dest_index}{$subindex}{'user'} = 0;
		}
		if ($source_ref->{$source_index}{$subindex}{'link'}) {
			$dest_ref->{$dest_index}{$subindex}{'link'} = $source_ref->{$source_index}{$subindex}{'link'};
		} else {
			$dest_ref->{$dest_index}{$subindex}{'link'} = 0;
		}
	}
	return 1;
}

#
# subroutine to get a request from server via LWP
#
sub lwp_fetch {
	my ($content) = (@_);
	my ($method,$esc_content,$ua,$request,$response);	
	$method = 'POST';
	$esc_content = uri_escape($content);
	$ua = new LWP::UserAgent;
	$ua->env_proxy();
	$request = new HTTP::Request($method,$server);
	$request->content_type('application/x-www-form-urlencoded');
	$request->content($content);
	$request->authorization_basic($uname, $pass);
	$response = $ua->request($request);
	if ($response->is_success) {
		return $response->content;
	} else {
		die "Error fetching $content via LWP!\n" if (! $Q);
		return 0;
	}
}

#
# subroutine to put a leading 0 on a string if needed
#
sub two_digit {
	my (@list) = (@_);
	my ($item,@return_list);
	for $item (@list) {
		$item = "0". $item if ($item !~ /\d{2}/);	
		push (@return_list, $item);
	}
	return @return_list;
}

#
# subroutine to return number of days between two dates
#
sub days_length {
	my ($begin,$end) = (@_);	
	my ($num,$stime,$etime,$sd,$ed,$sm,$em,$sy,$ey);
	($sy,$sm,$sd) = $begin =~ (/(\d{4})(\d{2})(\d{2})/);
	($ey,$em,$ed) = $end =~ (/(\d{4})(\d{2})(\d{2})/);
	$sy = $sy - 1900;
	$sm = $sm - 1;
	$ey = $ey - 1900;
	$em = $em - 1;
	$stime = timelocal("0","0","12",$sd,$sm,$sy);
	$etime = timelocal("0","0","12",$ed,$em,$ey);
	$num = $etime - $stime;
	$num = $num / 86400;
	if ($num =~ /^(\d+)\.\d+$/) {	
		$num = $1;
		$num++;
	}	
	return $num;
}

#
# subroutine to get the date x days in the future
#
sub future_date {
	my ($today,$x) = (@_);
	my ($tom,$d,$m,$y);
	($y,$m,$d) = $today =~ (/(\d{4})(\d{2})(\d{2})/);
	$y = $y - 1900;
	$m = $m - 1;
	$tom = timelocal("0","0","12",$d,$m,$y);
	$tom += ($x * 86400);
	($d,$m,$y) = (localtime($tom))[3,4,5];
	$m++;
	$y += 1900;
	($d,$m,$y) = &two_digit($d,$m,$y);
	$tom = $y . $m . $d;
	return $tom;
}

#
# subroutine to print a display of a number in same spot
#
sub display_counter {
	my ($x) = (@_);
	my ($y);
	if ($x =~ /\d+/) {
		$y = $x - 1;
		$y = length $y;
	} else {
		$y = 1;
	}
	$y += 2;
	for ( 1..$y ) {
		print "\b";
	}	
	print "[$x]";
	return 1;
}

#
# subroutine to debug wc output
#
sub debug_wc {
	my ($ref) = (@_);
	my ($index,$subindex);
	for $index (sort keys %$ref) {
		for $subindex (sort keys %{ $ref->{$index} }) {
			print "in: $index:$subindex\n";
			print "  mo: $$ref{$index}{$subindex}{'modified'}\n";
			print "  us: $$ref{$index}{$subindex}{'user'}\n";
			print "  id: $$ref{$index}{$subindex}{'date'}\n";
			print "  sh: $$ref{$index}{$subindex}{'shour'}\n";
			print "  eh: $$ref{$index}{$subindex}{'ehour'}\n";
			print "  st: $$ref{$index}{$subindex}{'string'}\n";
			print "  li: $$ref{$index}{$subindex}{'link'}\n";
			print "  rs: $$ref{$index}{$subindex}{'rsec'}\n";
			print "  no: $$ref{$index}{$subindex}{'notes'}\n";
		}
	}
	return 1;
}

#
# subroutine to debug db output
#
sub debug_db {
	my ($ref,$id) = (@_);
	my ($index,$subindex);
	if ($id) {
		$index = $id;
		for $subindex (sort keys %{ $ref->{$index} }) {
			print "in: $index:$subindex\n";
			print "   d: $ref->{$index}{$subindex}{'date'}\n";
			print "  sh: $ref->{$index}{$subindex}{'shour'}\n";
			print "  eh: $ref->{$index}{$subindex}{'ehour'}\n";
			print "  st: $ref->{$index}{$subindex}{'string'}\n";
		}
	} else {
		for $index (sort keys %$ref) {
			for $subindex (sort keys %{ $ref->{$index} }) {
				print "in: $index:$subindex\n";
				print "   d: $ref->{$index}{$subindex}{'date'}\n";
				print "  sh: $ref->{$index}{$subindex}{'shour'}\n";
				print "  eh: $ref->{$index}{$subindex}{'ehour'}\n";
				print "  st: $ref->{$index}{$subindex}{'string'}\n";
			}
		}
	}
	return 1;
}

#
# subroutine to dump a db record
#
sub dump_db {
	my ($r) = (@_);
	my ($year,$month,$day,$sh,$sm,$eh,$em,$id,%items,$x);
	my ($key,$key2,$y,$z);
	print "\nworking on: ";
	print "$r->{'description'}\n";
	for $key (sort keys %$r) {
		next if (($key eq "raw") || ($key eq "description"));
		print "key: $key";
		if (($key eq "begin") || ($key eq "end")) {
			print "\n";
			$y = 0;
			for ( @{ $r->{$key} } ) {
				print "  $y: $r->{$key}[$y]\n";
				$y++;
			}
		} elsif  (($key eq "alarm") || ($key eq "repeat")) {
			print "\n";
			for $key2 (sort keys %{ $r->{$key} } ) {
				if (($key2 eq "days") || ($key2 eq "end")) {
					$z = 0;
					print "  $key2\n";
					for (@{ $r->{$key}{$key2} }) {
						print "    $z: $r->{$key}{$key2}[$z]\n";
						$z++;
					}
				} else {
					print "  $key2: $r->{$key}{$key2}\n";
				}
			}
		} else {
			print "  val: $r->{$key}\n";
		}
	}	
	return 1;	
}

#
# debugging
#
sub dump_config {
	print "user: $uname\n";
	print "pass: $pass\n";
	print "server: $server\n";
	print "cal: $cal\n";
	print "device: $device\n";
	print "q: $Q\n";
	return 1;
}

#
# subroutine to print out usage screen
#
sub help {
	print <<HELP;

Usage: $prog [-c <cal>] [-u <user>] [-p <pass>] [-d <device>] [-s <server>] [-qtfa]
Where:
  <cal>     = WebCal calendar name to synch with. 
  <user>    = WebCal user name for given calendar.
  <pass>    = WebCal password for given user name.
  <device>  = Serial device that palm pilot is connected to 
               Default: /dev/ttyqe
  <server>  = Full URL for WebCal server synch cgi.
               Default: http://localhost/cgi-bin/webcal/protected/webcal_synch_server.cgi

If no password is given, you will be prompted for one.

You can also specify these options in a .wcsynchrc file placed in your home
directory.  Put one option per line.  Example .wcsynchrc file:

# start .wcsynchrc
cal mycal
user me
device /dev/cua0
server http://myserver/cgi-bin/webcal/protected/webcal_synch_server.cgi
# end .wcsynchrc

Other options:

Use the -q switch to suppress warning messages.
Use the -t switch to test and see what would be done.  No changes will be made.
Use the -f switch to force all WebCal items to be written to your Pilot, and vice-versa.
Use the -a switch to have WebCal items from subscribed-to calendars also be put on Pilot.

HELP
	exit;
}
