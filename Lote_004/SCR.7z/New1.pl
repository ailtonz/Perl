#!/usr/bin/perl
my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime time;
 
print "$mday\n";
print "$mon+1\n";
print "$year\n";