#!/usr/bin/perl
 
my ($second, $minute, $hour, $dayOfMonth, $month, $yearOffset, $dayOfWeek, $dayOfYear, $daylightSavings) = localtime();
 
print "$dayOfMonth\n";
print "$month\n";
