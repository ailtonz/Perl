#!/usr/bin/perl
my ($second, $minute, $hour, $dayOfMonth, $month, $yearOffset, $dayOfWeek, $dayOfYear, $daylightSavings) = localtime();
$year = 1900 + $yearOffset;
$month++;
print "\n",$month,"\n",$dayOfMonth,"\n",$year,"\n";

print $year,$month,$dayOfMonth,"_",$hour;