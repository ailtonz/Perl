#!c:/Perl/perl.exe -w
use strict;
use warnings;

print $ARGV[0];