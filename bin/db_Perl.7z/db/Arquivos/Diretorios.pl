#!/usr/bin/perl 
#use strict;

mkdir("c:\\tmp de 007",0764);
#close (NEWDIR);