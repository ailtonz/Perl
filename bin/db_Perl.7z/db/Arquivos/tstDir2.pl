#!c:/Perl/perl.exe -w

use strict;
use warnings;
my $dir = "C:/Tmp/bkp";

if(!-d $dir){mkdir $dir;}