#!c:/Perl/perl.exe -w

use strict;
use warnings;

open (MYFILE, '>>data.txt');
print MYFILE "Bob\n";