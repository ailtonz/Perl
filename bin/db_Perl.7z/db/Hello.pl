use Tk;
$janela=MainWindow->new;
$janela->Button(
-text=>"Oi, Turma!!",
-command=>\&Sair)->pack;
MainLoop;
sub Sair {
exit;
}