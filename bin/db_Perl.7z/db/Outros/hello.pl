# Copyright - Well House Consultants, 2003
# Perl Basics - first program!
print "Hello; Welcome to this Perl course ";