# hello_again - second program!
# Good idea to say what the program does,
# who wrote it, which version it is ...
print # message to user
        "Hello; Welcome to this Perl course. \n\n\n\n";
print # another message to user
        "We'll do an exercise soon. ";
# We'll make it more interesting soon!