# ages
# input
print "please enter first age: ";
$age1 = <STDIN> ;
print "please enter second age: ";
$age2 = <STDIN> ;
# get difference
$difference = $age1 - $age2 ;
# output
print "The second person is ";
print $difference;
print " years younger than the first\n";