# ave2
# input
print "please enter first age: ";
$age1 = <STDIN> ;
print "please enter second age: ";
# get average
print "The average age is ",$average = ($age1 + ($age2 = <STDIN>))/ 2 , "\n";
# following line not good - too confusing!
print "Ages ",$age1+0," and ",$age2;
# but an excellent class discussion