open (ARQ, ">SAIDA.TXT");
print ARQ "OK\n";
close ARQ;