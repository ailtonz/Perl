#! c:\perl\bin\perl.exe
use strict;
use warnings;
my @numero;
	$numero[0] = 23;
	$numero[1] = 12;
	$numero[2] = 1;
	$numero[3] = 3.67;
	$numero[4] = 211;
	print "\n";
	print "Primeiro numero: $numero[0]\n"; #Imprime o primeiro numero
	print "Ultimo numero: $numero[$#numero]\n"; #Imprime o ultimo numero