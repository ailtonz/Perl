#!/usr/bin/perl
print "Content-type: text/html \n\n"; 

print "Ola, Ailton!\n\n";

print "Conex�o OK!";
