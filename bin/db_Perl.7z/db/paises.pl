#!/usr/bin/perl
use strict;
use warnings;

my %paises = ();
	$paises{Brasil} = "Brasilia";
	$paises{EUA} = "Nova York";
	$paises{Franca} = "Paris";
	
	print "Capital do Brasil � $paises{Brasil}\n";
	print "Capital da Fran�a � $paises{Franca}\n";