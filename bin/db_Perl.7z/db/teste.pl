use Sys::Hostname;
    $host = hostname;
	
	print $host;