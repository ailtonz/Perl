my $diretorio="C:/Tmp/e-Mails/ENVIADOS";
$diretorio =~ s/\//\/g;
print $diretorio;
